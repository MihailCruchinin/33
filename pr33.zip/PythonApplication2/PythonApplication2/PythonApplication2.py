import kivy
kivy.require('1.0.7')
from kivy.animation import Animation
from kivy.app import App
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout

class MyApp(App):
    def animate(self, instance, button):
        animation = Animation(pos=(100, 100), t='out_bounce')
        animation += Animation(pos=(200, 100), t='out_bounce')
        animation &= Animation(size=(500, 500))
        animation += Animation(size=(100, 100))
        animation.start(button)

    def build(self):
       layout = BoxLayout()
       button1 = Button(size_hint=(None, None), text='plop1',
                    on_press=lambda instance: self.animate(instance, button2))
       button2 = Button(size_hint=(None, None), text='plop2',
                    on_press=lambda instance: self.animate(instance, button1))
       layout.add_widget(button1)
       layout.add_widget(button2)
       return layout

if __name__ == '__main__':
    MyApp().run()
